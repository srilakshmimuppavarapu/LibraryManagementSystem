package com.cg.plp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;
import com.cg.plp.service.ILibrarianService;
import com.cg.plp.service.IStudentService;
import com.cg.plp.service.IUserService;
import com.cg.plp.service.LibrarianServiceImpl;
import com.cg.plp.service.StudentServiceImpl;
import com.cg.plp.service.UserServiceImpl;


@WebServlet("/LMSController")
public class LMSController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
           
    public LMSController() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		
		int status=0;
		boolean addStatus=false;
		
		HttpSession session=request.getSession();
		
		IUserService userService=new UserServiceImpl();
		ILibrarianService librarianServiceImpl=new LibrarianServiceImpl();
		IStudentService studentServiceImpl=new StudentServiceImpl();
		
		BookBean bookBean=new BookBean();
		
		String operation=request.getParameter("action");
		
		if(operation!=null && operation.equals("Register"))
		{
			String userName = request.getParameter("userName");
			String password =  request.getParameter("password");
			String reEnterPassword = request.getParameter("reEnteredPassword");
			String email = request.getParameter("emailId");
			String role=request.getParameter("user");
			if(password.equals(reEnterPassword))
			{
				UserBean userBean = new UserBean();
				userBean.setName(userName);
				userBean.setPassword(password);
				userBean.setEmailId(email);
				userBean.setLibrarian(role);
				
				try
				{
					String registeredUserId = userService.addDetails(userBean);
		
					request.setAttribute("userid",registeredUserId);			
					getServletContext().getRequestDispatcher("/RegistrationStatus.jsp").forward(request,response);
				}
				catch (LibraryException e) 
				{
					session.setAttribute("error", e);
					request.getRequestDispatcher("/Registration.jsp").forward(request, response);
				}
			}
			else
			{
				String error="<center><font color=red>Registration is not Successful please do register again</font></center>";
				session.setAttribute("error", error);
				getServletContext().getRequestDispatcher("/Registration.jsp").forward(request,response);
				
			}	
		}
		
		if(operation!=null && operation.equals("login"))
		{
			try 
			{
				
				String userid=request.getParameter("userId");
				String password=request.getParameter("password");
					
				status=userService.isUserValid(userid,password);
				
				if(status==3)
				{
					String error="<center> <font color='red'> Invalid password </font> </center>";
					//out.println("<center> <font color='red'> Invalid username or password </font> </center>");
					request.setAttribute("errorLogin", error);
					RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
					rd.forward(request, response);
				}
				
				else if(status==4)
				{
					String error="<center> <font color='red'> Invalid username </font> </center>";
					//out.println("<center> <font color='red'> Invalid username or password </font> </center>");
					request.setAttribute("errorLogin", error);
					RequestDispatcher rd=request.getRequestDispatcher("/Login.jsp");
					rd.forward(request, response);
				}
				
				else if(status==1)
				{
					session.setAttribute("userid", userid);
					session.setAttribute("password", password);
					RequestDispatcher rd=request.getRequestDispatcher("/Librarian.jsp");
					rd.forward(request, response);
				}
				
				else if(status==2)
				{
					session.setAttribute("userid", userid);
					session.setAttribute("password", password);
					
					String userName=null;
					userName=userService.getUserName(userid);
					
					session.setAttribute("userName", userName);

					RequestDispatcher rd=request.getRequestDispatcher("/Student.jsp");
					rd.forward(request, response);
				}						
			}
			catch (LibraryException e) 
			{
				session.setAttribute("error", e);
				request.getRequestDispatcher("/Error.jsp").forward(request, response);
			}
		}
		
		
		//librarian functionalities
		try
		{
			if(operation!=null && operation.equals("librarianRegister"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("/LibrarianRegister.jsp");
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("RegisterLibrarian"))
			{
				String userName = request.getParameter("userName");
				String password =  request.getParameter("password");
				String reEnterPassword = request.getParameter("reEnteredPassword");
				String email = request.getParameter("emailId");
				String role=request.getParameter("user");
				if(password.equals(reEnterPassword))
				{
					UserBean userBean = new UserBean();
					userBean.setName(userName);
					userBean.setPassword(password);
					userBean.setEmailId(email);
					userBean.setLibrarian(role);
					
					try
					{
						String registeredUserId = userService.addDetails(userBean);
			
						request.setAttribute("userid",registeredUserId);			
						getServletContext().getRequestDispatcher("/RegistrationStatus.jsp").forward(request,response);
					}
					catch (LibraryException e) 
					{
						session.setAttribute("error", e);
						request.getRequestDispatcher("/Registration.jsp").forward(request, response);
					}
				}
				else
				{
					String error="<center><font color=red>Registration is not Successful please do register again</font></center>";
					session.setAttribute("error", error);
					getServletContext().getRequestDispatcher("/Registration.jsp").forward(request,response);
					
				}	
			}
			
			if(operation!=null && operation.equals("addBooks"))
			{
				int bookId=librarianServiceImpl.generateBookIdSeq();
				String id="LMS"+bookId;
				session.setAttribute("bookId", id);
				RequestDispatcher rd=request.getRequestDispatcher("/AddBooks.jsp");
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("addedBooks"))
			{
				String addedBookId=request.getParameter("id");
				String bookName=request.getParameter("bookName");
				String author1=request.getParameter("author1");
				String author2=request.getParameter("author2");
				String publisher=request.getParameter("publisher");
				String yearOfPublication=request.getParameter("yearOfPublication");
				int numberOfCopies=Integer.parseInt(request.getParameter("numberOfCopies"));
				
				bookBean.setBookId(addedBookId);
				bookBean.setBookName(bookName);
				bookBean.setAuthor1(author1);
				bookBean.setAuthor2(author2);
				bookBean.setPublisher(publisher);
				bookBean.setYearOfPublication(yearOfPublication);
				bookBean.setNoOfCopies(numberOfCopies);
				
				addStatus=librarianServiceImpl.addBooks(bookBean);
				
				if(addStatus)
				{
					String error="<font color=blue><h2>Book is added successfully</h2></font>";
					request.setAttribute("error", error);
					RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
					rd.forward(request, response);
				}
				else
				{
					String error="Failed to add book";
					request.setAttribute("AddBooksError", error);
					RequestDispatcher rd=request.getRequestDispatcher("/AddBooks.jsp");
					rd.forward(request, response);
				}
			}
			
			if(operation!=null && operation.equals("removeBooks"))
			{
				ArrayList<BookBean> booksInventory1=librarianServiceImpl.showBooks();
				session.setAttribute("booksInventory", booksInventory1);
				
				RequestDispatcher rd=request.getRequestDispatcher("/RemoveBooks.jsp"); 
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("removedBooks"))
			{
				boolean removedStatus=false;
				String removedBookId=request.getParameter("bookId");
				int numCopy=Integer.parseInt(request.getParameter("numCopy"));
				
				removedStatus=librarianServiceImpl.removeBook(numCopy,removedBookId);
				
				if(removedStatus)
				{
					String error="Updations for the book is done successfully";
					request.setAttribute("error", error);
					RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
					rd.forward(request, response);
				}
				else
				{					
					String error="Failed to remove book";
					request.setAttribute("error", error);
					RequestDispatcher rd=request.getRequestDispatcher("/LibrarianStatus.jsp");
					rd.forward(request, response);
				} 
			}
			
			if(operation!=null && operation.equals("manageBooks"))
			{
				ArrayList<BookRegistrationBean> bookRegistrations=librarianServiceImpl.showRegisteredBooks();
				session.setAttribute("bookRegistrations", bookRegistrations);
				
				RequestDispatcher rd=request.getRequestDispatcher("/grantBooks.jsp"); 
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("grant"))
			{
				String transactionId=null;
				
				String registrationId=request.getParameter("registrationId"); 
				String bookId=request.getParameter("bookId"); 
				
				transactionId=librarianServiceImpl.grantBook(registrationId,bookId);
				session.setAttribute("transactionId", transactionId);
				
				RequestDispatcher rd=request.getRequestDispatcher("/Granted.jsp"); 
				rd.forward(request, response);
			}			
		
			//Student functionalities
			
			if(operation!=null && operation.equals("request"))
			{
				ArrayList<BookBean> booksInventory;
				
				booksInventory = studentServiceImpl.showBooks();
				session.setAttribute("booksInventory", booksInventory);
				
				RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("requestedBook"))
			{
				String requestedBookId=request.getParameter("bookId");
				request.setAttribute("requestedBookId", requestedBookId);
				
				int bookStatus;
				
				bookStatus = studentServiceImpl.isBookAvailable(requestedBookId);
				if(bookStatus==1)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/BookAvailable.jsp"); 
					rd.forward(request, response);
				}
				else if(bookStatus==2)
				{
					String error="<center> <font color='red'>Requested book is out of copies</font></center>";
					request.setAttribute("errors", error);
					RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
					rd.forward(request, response);
				}
				else if(bookStatus==3)
				{
					String error="<center> <font color='red'>Entered bookid doesnot match with any of the books</font></center>";
					request.setAttribute("errors", error);
					RequestDispatcher rd=request.getRequestDispatcher("/RequestBook.jsp"); 
					rd.forward(request, response);
				}			
			}
			
			if(operation!=null && operation.equals("placeRequest"))
			{
				String registrationId;
				String requestedBookId=request.getParameter("requestedBookId");
				
				String userId=(String)session.getAttribute("userid");

				registrationId = studentServiceImpl.addRequest(userId,requestedBookId);
				session.setAttribute("registrationId",registrationId);
				RequestDispatcher rd=request.getRequestDispatcher("/RequestSuccess.jsp"); 
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("return"))
			{			
				String userid=(String) session.getAttribute("userid");
				
				ArrayList<BookRegistrationBean> userBooksInventory;
				
				userBooksInventory = studentServiceImpl.showUserBooks(userid);
				session.setAttribute("userBooksInventory",userBooksInventory);	
				
				RequestDispatcher rd=request.getRequestDispatcher("/ReturnBook.jsp"); 
				rd.forward(request, response);
			}
			
			if(operation!=null && operation.equals("fine"))
			{
				int fine=0;
				
				String registrationId=request.getParameter("registrationId");
				String bookId=request.getParameter("bookId");

				fine = studentServiceImpl.returnBook(registrationId,bookId);
				
				request.setAttribute("fine", fine);
				
				RequestDispatcher rd=request.getRequestDispatcher("/Fine.jsp"); 
				rd.forward(request, response);
			}
		}
		catch(StudentException e)
		{
			session.setAttribute("error", e);
			RequestDispatcher rd=request.getRequestDispatcher("/StudentErrorPage.jsp"); 
			rd.forward(request, response);
		}
		catch(LibraryException e)
		{
			session.setAttribute("error", e);
			RequestDispatcher rd=request.getRequestDispatcher("/Error.jsp"); 
			rd.forward(request, response);
		}			
	}
}
