package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.exception.LibraryException;

public interface ILibrarianService 
{
	public boolean addBooks(BookBean bookBean) throws LibraryException;

	public boolean removeBook(int numCopy,String bookId) throws LibraryException;

	public ArrayList<BookBean> showBooks() throws LibraryException;

	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException;

	public String grantBook(String registrationId, String bookId) throws LibraryException;

	public int generateBookIdSeq()  throws LibraryException;
	
}
