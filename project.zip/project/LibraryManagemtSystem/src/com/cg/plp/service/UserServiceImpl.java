package com.cg.plp.service;

import com.cg.plp.bean.UserBean;
import com.cg.plp.dao.ILMSDao;
import com.cg.plp.dao.LMSDaoImpl;
import com.cg.plp.exception.LibraryException;

public class UserServiceImpl implements IUserService
{
	ILMSDao lmsDao=new LMSDaoImpl();
	
	@Override
	public int isUserValid(String userId, String password) throws LibraryException
	{
		return lmsDao.isUserValid(userId,password);
	}

	@Override
	public String addDetails(UserBean userBean) throws LibraryException
	{
		return lmsDao.addDetails(userBean);
	}

	@Override
	public String getUserName(String userId) throws LibraryException
	{
		return lmsDao.getUserName(userId);
	}

}
